#!/bin/bash
# export_pr.sh - when (and only when) you want to open a pull request upstream. It builds a THROWAWAY branch
# `pr-export` from upstream/main holding ONLY the feature (no CI, version bump, Turkish strings, docs), so the
# maintainer's rules are met without anyone keeping a PR branch in sync. Your `main` is not touched.
#
#   bash export_pr.sh        # then follow what it prints
set -e
cd "$(git rev-parse --show-toplevel)"
git remote get-url upstream >/dev/null 2>&1 || git remote add upstream https://github.com/kushagrasinghx/BitChord.git
git fetch upstream
[ "$(git rev-parse --abbrev-ref HEAD)" = main ] || { echo "Run this on main."; exit 1; }
git diff --quiet || { echo "Commit or stash your changes on main first."; exit 1; }

FEATURE=(
  "app/src/main/java/com/music/bitchord/wear/WearLyricsSync.kt"
  "app/src/main/java/com/music/bitchord/playback/PlaybackService.kt"
  "app/src/main/java/com/music/bitchord/ui/MainViewModel.kt"
  "tv/src/main/java/com/music/bitchord/wear/WearLyricsSync.kt"
  "wearos/build.gradle.kts"
  "wearos/src/main/java/com/music/bitchord/wear/ui/NowPlayingScreen.kt"
  "wearos/src/main/java/com/music/bitchord/wear/ui/WearApp.kt"
  ":(glob)wearos/src/main/java/com/music/bitchord/wear/ui/Lyric*.kt"
  ":(glob)wearos/protocol/**/lyrics/*.kt"
  "wearos/src/main/res/values/strings_lyrics.xml"
  ":(glob)wearos/src/main/res/drawable/ic_lyrics*.xml"
)
BASE=$(git merge-base HEAD upstream/main)
git diff "$BASE" HEAD -- "${FEATURE[@]}" > /tmp/pr-export.patch
[ -s /tmp/pr-export.patch ] || { echo "No feature changes found relative to upstream."; exit 1; }
git checkout -f -B pr-export upstream/main
git apply --3way --index /tmp/pr-export.patch
echo
git status --short
echo
echo "Only feature files should be listed above. If so:"
echo "  git commit -m \"Watch app: synced lyrics screen\""
echo "  git push -u origin pr-export --force"
echo "  open: https://github.com/kushagrasinghx/BitChord/compare/main...Myrtle-tr:BitChord:pr-export"
echo "When done, return to your work with:  git checkout -f main"
